from  turtle import Turtle


class Paddle:

    def __init__(self):
        paddle = Turtle()
        paddle.penup()
        paddle.goto(350, 0)
        paddle.shape("square")
        paddle.color("white")
        paddle.shapesize(stretch_wid=5, stretch_len=1)


    def go_up(self):
        new_y = paddle.ycor() + 20
        paddle.goto(paddle.xcor(), new_y)

    def go_down(self):
        new_y = paddle.ycor() - 20
        paddle.goto(paddle.xcor(), new_y)

